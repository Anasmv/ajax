<?php
session_start();
if(isset($_POST['value1']) && isset($_POST['value2']) && isset($_POST['value3']) && isset($_POST['value4'])):
	echo "<h1>data from ajx.php page</h1>";
	echo	'<br> value1 = ' . $_POST['value1'];
	echo	'<br> value2 = ' . $_POST['value2'];
	echo	'<br> value3 = ' . $_POST['value3'];
	echo	'<br> value4 = ' . $_POST['value4'];
endif;

if(isset($_SESSION['$%Ytttfgv'])):
	$tkkk = '$2y$10$'.$_SESSION['$%Ytttfgv'];
endif;

if(isset($_SESSION['$%Ytttfgv']) && isset($_SESSION['token']) && isset($_POST['token_set']) && ($tkkk == $_SESSION['token'])  && ($_SESSION['$%Ytttfgv'] <> $_SESSION['token']) && ($_SESSION['$%Ytttfgv'] == $_POST['token_set'])):
	echo '<br>';
	echo ' <div id="tkn_div2"> token = '.$_SESSION['$%Ytttfgv'] . "</div>";
	if( ($_SESSION['$%Ytttfgv'] == $_POST['token_set']) && ($_SESSION['token'] <> $_POST['token_set']) &&  ($tkkk == $_SESSION['token'])):
		echo '<br>token match<br>';
	else:
		echo '<br>token missmatch<br>';
	endif;
endif;

if(isset($_POST['destroy_token'])):
	session_destroy();
	echo 'token deleted reload to create new token';
endif;
?>