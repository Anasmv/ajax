<?php
session_start();
if(isset($_SESSION['name']))
{
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$dbname = 'chat_database'; 
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) 
	or die ('Error connecting to mysql');
	if(!$conn)
	{
		echo 'db connection error';
	}
	if(isset($_POST['message']) && $_POST['message'] != "")
	{
		$message = $_SESSION['name']. ': ' .$_POST['message'];
		$sql_ins = "INSERT INTO `chat`(`Id`, `Text`) VALUES (NULL, '$message')";
		mysqli_query($conn, $sql_ins);
	}
		
	$sql = "SELECT `Text` FROM `chat` ORDER BY `Id` DESC";
	$result = mysqli_query($conn, $sql);
	 
	while($row = mysqli_fetch_array($result))
	echo $row['Text']."\n";
}
?>