<?php ini_set('upload_max_filesize', '999999M'); ini_set('post_max_size', '999999M'); ini_set('max_input_time', 900000); ini_set('max_execution_time', 900000); ini_set('memory_limit', '999999M');

print_r($_POST);
//echo $_POST['name'];

echo '<br>';

?>
<?php
if( isset($_POST['name']) and isset($_POST['email']) and isset($_POST['phone']) ):
	echo $_POST['name'] ."<br />";
	echo $_POST['email'] ."<br />";
	echo $_POST['phone'] ."<br />";
	echo $_POST['gender'] ."<br />";
	echo "==============================<br />";
	echo "All Data Submitted Successfully!";
endif;
?>